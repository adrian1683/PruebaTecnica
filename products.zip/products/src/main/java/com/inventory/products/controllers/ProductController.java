package com.inventory.products.controllers;

import com.inventory.products.models.Product;
import com.inventory.products.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public List<Product> products(){
        return productService.listProducts();
    }

    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProductoById(@PathVariable Integer id){
        try{
            Product product = productService.getProductById(id);
            return new ResponseEntity<Product>(product, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/products")
    public void saveProduct(@RequestBody Product product){
        productService.saveProduct(product);
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<?> updateProduct(@RequestBody Product product, @PathVariable Integer id){
        try {
            Product currentProduct = productService.getProductById(id);
            currentProduct.setName(product.getName());
            currentProduct.setDescription(product.getDescription());
            currentProduct.setPrice(product.getPrice());
            currentProduct.setAmount(product.getAmount());
            productService.saveProduct(currentProduct);
            return new ResponseEntity<Product>(HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/products/{id}")
    public void deleteProduct(@PathVariable Integer id){
        productService.deleteProduct(id);
    }
}
